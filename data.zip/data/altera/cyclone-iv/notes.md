# NOTES

For some unknown reason, they decided to concat parts in this family. Some of the columns are "Fxxx/Uyyy", which here refers to two separate parts... GRAH
